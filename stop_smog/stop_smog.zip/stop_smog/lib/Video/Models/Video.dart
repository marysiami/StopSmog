class Video {
  final String title;
  final String url;

  const Video({this.title, this.url});
}