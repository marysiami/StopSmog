// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'Values.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

Values _$ValuesFromJson(Map<String, dynamic> json) {
  return Values(date: json['date'] as String, value: json['value'] as double);
}

Map<String, dynamic> _$ValuesToJson(Values instance) =>
    <String, dynamic>{'date': instance.date, 'value': instance.value};
