import 'package:stop_smog/Navigation/Models/Menu_item.dart';

const SampleMenuItems = const [
  MenuItem( id:1, title: 'Home'),
  MenuItem( id:2, title: 'Blog'),
  MenuItem( id:3, title: 'Quiz'),
];