import 'package:flutter/cupertino.dart';

class MenuItem {
  final int id;
  final String title;

  const MenuItem({ @required this.id, @required this.title});
}